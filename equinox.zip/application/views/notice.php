<?php
$this->load->view('includes/header');
?>
<section id="faq-hero" class="testimonial d-flex align-items-center">
    <div class="container position-relative text-center text-lg-start aos-init aos-animate" data-aos="zoom-in" data-aos-delay="100">
      <div class="row">
        <div class="col-lg-12 pt-5 justify-content-center d-flex f-row">
          <h1>IMPORTANT UPDATES AND<span> NOTICE</span></h1>
          <h2>go through schedule</h2>
        </div>
      </div>
    </div>
</section>


<main id="main">
	<!-- ======= Why Us Section ======= -->
    <section id="faq" class="faq">
        <div class="container" data-aos="fade-up">
            <div class="section-title notice-title">
                <!-- <h2>Follow as per</h2> -->
                <p>TRADING UPDATES</p>
            </div>
            <div class="row">
                <div class="col-lg-12 col-sm-12">
                    <div class="" data-aos="fade-up" data-aos-delay='100'>
                        <div class="card-body">
                            <h5 class="card-title">Daylight Saving Time</h5>
                            <!-- <h6 class="card-subtitle mb-2 text-muted">#rule 1</h6> -->
                            <p class="card-text">
                                Some quick example text to build on the
                                card title and make up the
                                bulk of the card's content. Some quick example text to build on the
                                card title and make up the
                                bulk of the card's content. Some quick example text to build on the
                                card title and make up the
                                bulk of the card's content.
                            </p>
                            <a href="#" class="card-link">Card link</a>
                            <a href="#" class="card-link">Another link</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="section-title notice-title">
                <!-- <h2>Follow as per</h2> -->
                <p>TRADING UPDATES</p>
            </div>
            <div class="row">
                <div class="col-lg-12 col-sm-12">
                    <div class="" data-aos="fade-up" data-aos-delay='100'>
                        <div class="card-body">
                            <h5 class="card-title">Daylight Saving Time</h5>
                            <!-- <h6 class="card-subtitle mb-2 text-muted">#rule 1</h6> -->
                            <p class="card-text">
                                Some quick example text to build on the
                                card title and make up the
                                bulk of the card's content. Some quick example text to build on the
                                card title and make up the
                                bulk of the card's content. Some quick example text to build on the
                                card title and make up the
                                bulk of the card's content.
                            </p>
                            <a href="#" class="card-link">Card link</a>
                            <a href="#" class="card-link">Another link</a>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </section><!-- End Pricing -->
	
  </main><!-- End #main -->


<?php
$this->load->view('includes/footer');
?>